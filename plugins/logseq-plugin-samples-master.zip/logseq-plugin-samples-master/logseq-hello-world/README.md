## Hello World Sample

This is a Hello World sample that just get you started :)

### Demo

![demo](./demo.gif)

### API

[![npm version](https://badge.fury.io/js/%40logseq%2Flibs.svg)](https://badge.fury.io/js/%40logseq%2Flibs)

##### Logseq

- `ready (callback?: (e: any) => void | {}): Promise<any>`

##### Logseq.App

- `showMsg: (content: string, status?: 'success' | 'warning' | string) => void`

### Running the Sample

- `npm install && npm run build` in terminal to install dependencies.
- `Load unpacked plugin` in Logseq Desktop client.
