// to enable css template string syntax highlighting via vscode-styled-components
export const css = (t, ...args) => String.raw(t, ...args);
