# Logseq Query Playground Plugin

![](demo.gif)
