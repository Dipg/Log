export default {
  base: './',
  optimizeDeps: {
    exclude: ['dayjs'],
  },
}
